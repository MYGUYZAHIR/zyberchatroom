# Simple Chatroom

A minimal real-time chatroom application using **Express** and **Socket.io**.  
- Ready to publish to GitHub.
- Ready to deploy on Glitch / Replit / Heroku with no changes.

## Quick start (locally)
```bash
npm install
npm start
```
Then open http://localhost:3000

## Deploying on Glitch
- Import this repository into Glitch or upload files.
- Glitch sets the `PORT` environment variable automatically; the app uses it.

## Notes
- This app stores messages in memory and is not intended for production use.
- If you want persistent storage, connect a database (MongoDB, Supabase, etc.).
- Feel free to customize the UI in `public/style.css` and front-end behaviour in `public/client.js`.