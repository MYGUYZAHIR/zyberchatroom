// client.js - connects to socket.io and handles UI interactions
const socket = io();

const messagesEl = document.getElementById('messages');
const form = document.getElementById('chatForm');
const input = document.getElementById('text');
const mynameEl = document.getElementById('myname');
const changeNameBtn = document.getElementById('changeNameBtn');

let username = localStorage.getItem('chat_username') || '';

function setUsername(name) {
  username = name || 'Anonymous';
  mynameEl.textContent = username;
  localStorage.setItem('chat_username', username);
}

if (!username) {
  const chosen = prompt('Pick a display name (optional):', 'Anonymous') || 'Anonymous';
  setUsername(chosen);
} else {
  setUsername(username);
}

changeNameBtn.addEventListener('click', () => {
  const chosen = prompt('Change your display name:', username) || username;
  setUsername(chosen);
});

function addMessage(msg, me=false) {
  const li = document.createElement('li');
  li.className = me ? 'me' : '';
  const meta = document.createElement('span');
  meta.className = 'meta';
  const time = new Date(msg.ts);
  meta.textContent = `${msg.username} • ${time.toLocaleTimeString()}`;
  li.appendChild(meta);
  const txt = document.createElement('div');
  txt.textContent = msg.text;
  li.appendChild(txt);
  messagesEl.appendChild(li);
  // auto-scroll
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

// history received
socket.on('history', (arr) => {
  messagesEl.innerHTML = '';
  arr.forEach(m => addMessage(m, m.username === username));
});

socket.on('message', (m) => {
  addMessage(m, m.username === username);
});

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  const payload = { username, text, ts: Date.now() };
  socket.emit('message', payload);
  input.value = '';
});