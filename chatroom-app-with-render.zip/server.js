// server.js - minimal Express + Socket.io chat server
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Serve static files from 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Simple in-memory message buffer (last 200 messages)
const messageHistory = [];

io.on('connection', (socket) => {
  console.log('user connected:', socket.id);

  // Send recent chat history to newly connected client
  socket.emit('history', messageHistory);

  // Receive a chat message from a client
  socket.on('message', (payload) => {
    // payload should be { username, text, ts }
    if (!payload || typeof payload.text !== 'string') return;
    const msg = {
      id: Date.now() + Math.random().toString(36).slice(2,8),
      username: payload.username || 'Anon',
      text: payload.text.slice(0, 2000), // limit length
      ts: payload.ts || Date.now()
    };
    messageHistory.push(msg);
    if (messageHistory.length > 200) messageHistory.shift();
    io.emit('message', msg);
  });

  socket.on('disconnect', () => {
    console.log('user disconnected:', socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});